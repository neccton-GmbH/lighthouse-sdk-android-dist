/**
 * Automatically generated file. DO NOT MODIFY
 */
package ai.neccton.lighthouse;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "ai.neccton.lighthouse";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String LIGHTHOUSE_SDK_VERSION = "0.1.1";
}

package ai.neccton.lighthouse

import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.SerializationException
import kotlinx.serialization.descriptors.buildClassSerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.*

@Serializable data class CallToAction(val identifier: String, val translation: String)
@Serializable data class MessageContent(val identifier: String, val category: String, val language: String, val country: String, val title: String, val body: String)
@Serializable data class CustomerMessage(val customerMessageId: String, val message: MessageContent, val callToActions: List<CallToAction>, val readDate: String?, val archivedDate: String?, val createDate: String)
@Serializable data class PageResponse<T>(val data: List<T>, val currentPage: Int, val totalPages: Int, val totalItems: Int, val pageSize: Int, val hasNext: Boolean, val hasPrevious: Boolean)
@Serializable data class MessageReadAllResponse(val updatedMessages: Int)

@Serializable enum class EngagementInitiator { CUSTOMER, OPERATOR, SYSTEM }
@Serializable enum class LimitPeriod { DAILY, WEEKLY, MONTHLY, SESSION, CUSTOM }
@Serializable enum class MoneyLimitType { DEPOSIT, LOSS, STAKE, BALANCE }
@Serializable enum class RiskScoreArea { RG, AML }
@Serializable enum class KpiKey { DEPOSIT_AMOUNT, WITHDRAWAL_AMOUNT, ACTIVE_DAYS, PLAYING_DURATION, PLAYING_DURATION_NIGHT, BET_AVERAGE }

/**
 * Engagement fields are nullable because the API returns null for fields that
 * are documented as optional. This is especially common for active play breaks.
 */
@Serializable data class CustomerPlayBreak(
    val picInternalPlayBreakId: String? = null,
    val eventId: String? = null,
    val eventTimestamp: String? = null,
    val durationMinutes: Long? = null,
    val initiator: EngagementInitiator? = null,
    val playBreakEnd: String? = null,
    val playBreakStart: String? = null,
)
@Serializable data class CustomerTimeLimit(
    val picInternalTimeLimitId: String? = null,
    val eventId: String? = null,
    val eventTimestamp: String? = null,
    val startDate: String? = null,
    val endDate: String? = null,
    val period: LimitPeriod? = null,
    val customLimitDuration: Long? = null,
    val value: Long? = null,
    val initiator: EngagementInitiator? = null,
)
/** Currency metadata is absent when the API returns only an ISO currency code. */
@Serializable data class Currency(val currencyCode: String, val symbol: String? = null, val defaultFractionDigits: Int? = null, val displayName: String? = null, val numericCode: Int? = null, val numericCodeAsString: String? = null)
@Serializable data class CustomerMoneyLimit(
    val picInternalMoneyLimitId: String? = null,
    val eventId: String? = null,
    val eventTimestamp: String? = null,
    val type: MoneyLimitType? = null,
    val startDate: String? = null,
    val endDate: String? = null,
    val period: LimitPeriod? = null,
    val customLimitDuration: Long? = null,
    val value: Double? = null,
    @Serializable(with = CurrencySerializer::class) val currency: Currency? = null,
    val initiator: EngagementInitiator? = null,
)
@Serializable data class CustomerKpi(@SerialName("TODAY") val today: Double? = null, @SerialName("THIS_WEEK") val thisWeek: Double? = null, @SerialName("THIS_MONTH") val thisMonth: Double? = null, @SerialName("ALL_TIME") val allTime: Double? = null)

/** Numeric timeline entries, with the API's optional empty flag kept separately. */
@Serializable(with = CustomerRiskScoreTimelineSerializer::class)
data class CustomerRiskScoreTimeline(val entries: Map<String, Long>, val empty: Boolean? = null)

internal object CustomerRiskScoreTimelineSerializer : KSerializer<CustomerRiskScoreTimeline> {
    override val descriptor = buildClassSerialDescriptor("CustomerRiskScoreTimeline")

    override fun deserialize(decoder: Decoder): CustomerRiskScoreTimeline {
        val data = decoder.decodeSerializableValue(JsonObject.serializer())
        return CustomerRiskScoreTimeline(
            entries = data.filterKeys { it != "empty" }.mapValues { it.value.jsonPrimitive.long },
            empty = data["empty"]?.jsonPrimitive?.boolean,
        )
    }

    override fun serialize(encoder: Encoder, value: CustomerRiskScoreTimeline) {
        val data = buildJsonObject {
            value.entries.forEach { (key, score) -> put(key, score) }
            value.empty?.let { put("empty", it) }
        }
        encoder.encodeSerializableValue(JsonObject.serializer(), data)
    }
}

/** Accept both the live API's code string and the object documented in Swagger. */
internal object CurrencySerializer : JsonTransformingSerializer<Currency>(Currency.serializer()) {
    override fun transformDeserialize(element: JsonElement): JsonElement = when {
        element is JsonObject -> element
        element is JsonPrimitive && element.isString && element.content.isNotBlank() ->
            buildJsonObject { put("currencyCode", element.content) }
        else -> throw SerializationException("Expected a currency code string or currency object")
    }
}

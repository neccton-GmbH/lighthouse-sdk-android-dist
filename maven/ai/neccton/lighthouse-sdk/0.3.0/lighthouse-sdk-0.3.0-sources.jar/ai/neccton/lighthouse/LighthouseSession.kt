package ai.neccton.lighthouse

import android.util.Log
import io.ktor.http.*
import kotlinx.coroutines.*
import kotlinx.serialization.Serializable
import java.time.Instant
import java.util.Base64
import org.json.JSONObject

/** Configuration for [LighthouseSession.initialize]. */
data class InitializeOptions(
    /** Server environment. Defaults to production; ignored when [baseUrl] is supplied. */
    val env: Environment = Environment.PROD,
    /** Optional API base URL overriding [env]. */
    val baseUrl: String? = null,
    /** Default message language; uses the device locale, falling back to `en`. */
    val language: String? = null,
    /** Default message country; uses the device locale, falling back to `ZZ`. */
    val country: String? = null,
    /**
     * Reports token-refresh failures on the SDK background scope. Dispatch UI updates to the main thread.
     * Receives the exception itself, not the warning log text. Ordinary callback exceptions are logged
     * and contained. Cancellation is not reported.
     *
     * For scheduled refresh attempts:
     * - Network exceptions, such as [java.net.UnknownHostException], [java.net.ConnectException],
     *   and [java.net.SocketTimeoutException], retry after 5, 10, 20, 40, then 60 seconds.
     *   Further failures retry every 60 seconds until success or [LighthouseSession.destroy].
     * - Other non-HTTP exceptions, including response-decoding failures, use the same retry policy.
     * - Every [ApiError] stops the automatic retry cycle, including 429 and 5xx. `Retry-After`
     *   is not used. For 400/401/403, `onRefreshTokenExpired` also runs; obtain a new session.
     *
     * Successful refresh resets backoff and schedules refresh from the new token's expiry.
     * Unexpected errors reaching the scope-level fallback are reported without restarting the coroutine.
     *
     * This callback also reports failed refresh attempts triggered by an API call's 401 response;
     * that failure still propagates to the API caller, without starting a backoff loop on that path.
     * Initialization errors and ordinary message-request failures are thrown to the caller instead.
     * Error types above are examples, not an exhaustive list. Exception messages may contain server
     * response bodies; avoid logging sensitive content.
     *
     * Example:
     * ```kotlin
     * InitializeOptions(onRefreshFailed = { error ->
     *     when (error) {
     *         is java.net.UnknownHostException -> { /* DNS failure; scheduled refresh retries. */ }
     *         is ApiError -> { /* Inspect error.status; no automatic HTTP retry. */ }
     *         else -> { /* Record another refresh failure. */ }
     *     }
     * })
     * ```
     */
    val onRefreshFailed: ((Throwable) -> Unit)? = null,
)

/** Pagination and locale overrides for message queries. */
data class MessageListOptions(
    /** Zero-based page index. Ignored by [LighthouseSession.message]. */
    val page: Int = 0,
    /** Maximum messages requested per page. Ignored by [LighthouseSession.message]. */
    val limit: Int = 10,
    /** Message language override; null uses the session default. */
    val language: String? = null,
    /** Message country override; null uses the session default. */
    val country: String? = null,
)

/**
 * A customer session created by [initialize].
 *
 * Automatically refreshes the access token 60 seconds before its JWT expiry. Background refresh
 * failures are contained and reported through [InitializeOptions.onRefreshFailed]; see that property
 * for retry rules. If expiry cannot be decoded, no proactive timer is scheduled.
 *
 * Message operations throw failures to their caller. An HTTP 401 triggers one refresh attempt and,
 * if successful, one retry of the original request. Concurrent refresh callers share an in-flight
 * operation. A later 401 can trigger another refresh even after automatic retries have stopped.
 *
 * Catch [ApiError] to inspect an HTTP status, handle network/decoding exceptions as appropriate, and
 * always preserve [CancellationException]. Call [destroy] when discarding the session.
 */
class LighthouseSession private constructor(
    private val refreshToken: String,
    @Volatile private var accessToken: String,
    private val baseUrl: String,
    private val defaultLanguage: String,
    private val defaultCountry: String,
    private val onRefreshTokenExpired: (() -> Unit)?,
    private val onRefreshFailed: ((Throwable) -> Unit)?,
) {
    private val refreshManager = TokenRefreshManager(
        refreshAction = {
            val token = fetchAccessToken(baseUrl, refreshToken)
            accessToken = token
            refreshDelay(token)
        },
        onRefreshTokenExpired = onRefreshTokenExpired,
        onRefreshFailed = onRefreshFailed,
        logFailure = { error ->
            // Do not log server bodies or tokens, which may contain sensitive data.
            val description = if (error is ApiError) "HTTP ${error.status}" else error.javaClass.simpleName
            Log.w("LighthouseSDK", "Token refresh failure: $description")
        },
    )

    companion object {
        private const val REFRESH_THRESHOLD_MS = 60_000L

        /**
         * Exchanges a refresh token for an access token and starts automatic refresh scheduling.
         *
         * Initial exchange failures are thrown directly to this caller, with no automatic retry and
         * without invoking either refresh callback. Catch them around this suspend call. Subsequent
         * background failures use [InitializeOptions.onRefreshFailed], not this caller's catch block.
         *
         * @param refreshToken Refresh token obtained from your backend for this customer.
         * @param options Environment, base URL, locale defaults, and optional failure reporting.
         * @param onRefreshTokenExpired Called on the SDK background scope when a later refresh receives
         * HTTP 400, 401, or 403. Obtain a new refresh token and initialize a new session; destroy the old
         * session. Dispatch UI updates to the main thread. Ordinary callback exceptions are contained.
         * This notification is per rejected attempt, not guaranteed once for the session lifetime.
         * @return A session after the initial token exchange succeeds.
         * @throws ApiError If the initial token endpoint returns a non-success HTTP status.
         * @throws java.io.IOException For network failures such as DNS resolution or connection errors.
         * @throws CancellationException If initialization is cancelled.
         * @throws Exception Other transport, configuration, or response-decoding failures can propagate;
         * the listed exception types are not exhaustive.
         */
        suspend fun initialize(
            refreshToken: String,
            options: InitializeOptions = InitializeOptions(),
            onRefreshTokenExpired: (() -> Unit)? = null,
        ): LighthouseSession {
            val url  = options.baseUrl ?: options.env.baseUrl
            val lang = options.language ?: java.util.Locale.getDefault().language.ifBlank { "en" }
            val ctry = options.country  ?: java.util.Locale.getDefault().country.ifBlank { "ZZ" }
            val token = fetchAccessToken(url, refreshToken)
            return LighthouseSession(refreshToken, token, url, lang, ctry, onRefreshTokenExpired, options.onRefreshFailed)
                .also { it.scheduleRefresh(token) }
        }

        private suspend fun fetchAccessToken(baseUrl: String, refreshToken: String): String {
            @Serializable data class Body(val refreshToken: String)
            @Serializable data class Resp(val accessToken: String)
            return unauthenticatedRequest<Resp>(baseUrl, "/api/v1/authentication/accessToken", body = Body(refreshToken)).accessToken
        }
    }

    private fun refreshDelay(token: String): Long? = parseJwtExp(token)?.let {
        (it * 1000L - System.currentTimeMillis() - REFRESH_THRESHOLD_MS).coerceAtLeast(0)
    }

    private fun scheduleRefresh(token: String) {
        refreshDelay(token)?.let { refreshManager.schedule(it) }
    }

    private suspend fun doRefresh() = refreshManager.refresh()

    private suspend inline fun <reified T> req(
        path: String, method: HttpMethod = HttpMethod.Get, body: Any? = null, params: Map<String, String> = emptyMap(),
    ): T = try {
        authenticatedRequest(baseUrl, path, method, accessToken, body, params)
    } catch (e: ApiError) {
        if (e.status == 401) { doRefresh(); authenticatedRequest(baseUrl, path, method, accessToken, body, params) }
        else throw e
    }

    private fun localeParams(o: MessageListOptions) = mapOf(
        "language" to (o.language ?: defaultLanguage),
        "country"  to (o.country  ?: defaultCountry),
        "page"     to o.page.toString(),
        "limit"    to o.limit.toString(),
    )

    /**
     * Returns a page of customer messages.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param options Pagination and locale overrides.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun messages(options: MessageListOptions = MessageListOptions())         = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages", params = localeParams(options))
    /**
     * Returns a page of unread customer messages.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param options Pagination and locale overrides.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun unreadMessages(options: MessageListOptions = MessageListOptions())   = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages/unread", params = localeParams(options))
    /**
     * Returns a page of active customer messages.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param options Pagination and locale overrides.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun activeMessages(options: MessageListOptions = MessageListOptions())   = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages/active", params = localeParams(options))
    /**
     * Returns a page of archived customer messages.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param options Pagination and locale overrides.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun archivedMessages(options: MessageListOptions = MessageListOptions()) = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages/archived", params = localeParams(options))
    /**
     * Returns one customer message.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param messageId Customer message identifier.
     * @param options Locale overrides; page and limit are ignored.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun message(messageId: String, options: MessageListOptions = MessageListOptions()) =
        req<CustomerMessage>("/api/v1/customer/messages/$messageId", params = mapOf("language" to (options.language ?: defaultLanguage), "country" to (options.country ?: defaultCountry)))
    /**
     * Marks one customer message as read.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param messageId Customer message identifier.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun markMessageRead(messageId: String): Unit      = req("/api/v1/customer/messages/$messageId/read", method = HttpMethod.Patch)
    /**
     * Marks all customer messages as read and returns the server result.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun markAllMessagesRead(): MessageReadAllResponse = req("/api/v1/customer/messages/read-all", method = HttpMethod.Patch)
    /**
     * Archives one customer message.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param messageId Customer message identifier.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun archiveMessage(messageId: String): Unit       = req("/api/v1/customer/messages/$messageId/archive", method = HttpMethod.Patch)
    /**
     * Restores one archived customer message.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param messageId Customer message identifier.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun restoreMessage(messageId: String): Unit      = req("/api/v1/customer/messages/$messageId/restore", method = HttpMethod.Patch)

    /**
     * Records engagement with a message call to action using the current timestamp.
     *
     * On HTTP 401, attempts token refresh and retries the request once after success.
     * Request failures propagate to this caller; ordinary request errors do not invoke
     * [InitializeOptions.onRefreshFailed]. Only a failed token refresh invokes that callback.
     *
     * @param messageId Customer message identifier.
     * @param callToActionIdentifier Identifier of the call to action within the message.
     * @throws ApiError If the request or required token refresh returns a non-success HTTP status.
     * @throws java.io.IOException For network failures, including DNS and connection errors.
     * @throws CancellationException If the operation is cancelled, including cancellation while awaiting refresh.
     * @throws Exception Other transport or response-decoding failures may propagate.
     */
    suspend fun engageCallToAction(messageId: String, callToActionIdentifier: String): Unit {
        @Serializable data class Body(val engagementTimestamp: String)
        req<Unit>("/api/v1/customer/messages/$messageId/callToActions/$callToActionIdentifier/engagements",
            method = HttpMethod.Post, body = Body(Instant.now().toString()))
    }

    /**
     * Cancels the session's refresh scope, including pending timers, backoff waits, and refresh requests.
     * Cancellation is not reported through [InitializeOptions.onRefreshFailed]. Safe to call repeatedly.
     *
     * Discard this session afterward; its refresh scope cannot restart. This does not close the shared
     * HTTP client or cancel ordinary message requests owned by the calling application's coroutine.
     */
    fun destroy() { refreshManager.destroy() }
}

private fun parseJwtExp(token: String): Long? = runCatching {
    val payload = token.split(".").getOrNull(1) ?: return@runCatching null
    val padded = payload + "=".repeat((4 - payload.length % 4) % 4)
    JSONObject(String(Base64.getUrlDecoder().decode(padded))).getLong("exp")
}.getOrNull()

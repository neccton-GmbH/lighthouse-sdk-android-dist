package ai.neccton.lighthouse

/**
 * A non-success HTTP response from a Lighthouse endpoint.
 *
 * Inspect [status] rather than parsing the exception message. Network failures such as
 * [java.net.UnknownHostException] and response-decoding failures are not represented by this class.
 * The exception message includes the server response body and may contain sensitive information.
 *
 * During scheduled token refresh, every ApiError stops automatic retries, including 429 and 5xx.
 * HTTP 400/401/403 additionally invoke the session's `onRefreshTokenExpired` callback.
 * During a message operation, an initial 401 triggers token refresh and one request retry;
 * remaining failures propagate to the caller.
 *
 * @param message Server response body used to construct the exception message.
 * @property status HTTP response status code, for example 401, 429, or 503.
 */
class ApiError(val status: Int, message: String) : Exception("HTTP $status: $message")

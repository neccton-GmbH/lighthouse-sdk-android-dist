package ai.neccton.lighthouse

import kotlinx.coroutines.*

/** Owns the background timer and shares one refresh operation between all callers. */
internal class TokenRefreshManager(
    private val refreshAction: suspend () -> Long?,
    private val onRefreshTokenExpired: (() -> Unit)?,
    private val onRefreshFailed: ((Throwable) -> Unit)?,
    private val logFailure: (Throwable) -> Unit,
    dispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
    private val lock = Any()
    private val scope = CoroutineScope(
        SupervisorJob() + dispatcher + CoroutineExceptionHandler { _, error -> reportFailure(error) },
    )
    private var scheduled: Job? = null
    private var inflight: Deferred<Unit>? = null

    fun schedule(delayMs: Long) = synchronized(lock) {
        scheduled?.cancel()
        scheduled = scope.launch(start = CoroutineStart.LAZY) {
            delay(delayMs.coerceAtLeast(0))
            var retryDelay = 5_000L
            while (isActive) {
                try {
                    refresh()
                    return@launch
                } catch (e: CancellationException) {
                    throw e
                } catch (e: ApiError) {
                    // Every HTTP failure ends automatic retries, including 429 and 5xx.
                    return@launch
                } catch (e: Exception) {
                    // The shared refresh already reported this failure.
                    delay(retryDelay)
                    retryDelay = (retryDelay * 2).coerceAtMost(60_000L)
                }
            }
        }.also { it.start() }
    }

    suspend fun refresh() {
        val operation = synchronized(lock) {
            inflight?.takeUnless { it.isCompleted } ?: scope.async<Unit>(start = CoroutineStart.LAZY) {
                try {
                    val nextDelay = refreshAction()
                    currentCoroutineContext().ensureActive()
                    nextDelay?.let { schedule(it) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    if (e is ApiError && e.status in setOf(400, 401, 403)) {
                        notifySafely { onRefreshTokenExpired?.invoke() }
                    }
                    reportFailure(e)
                    throw e
                }
            }.also { operation ->
                inflight = operation
                operation.invokeOnCompletion {
                    synchronized(lock) {
                        if (inflight === operation) inflight = null
                    }
                }
                operation.start()
            }
        }
        operation.await()
    }

    private fun reportFailure(error: Throwable) {
        if (error is CancellationException) return
        logFailure(error)
        notifySafely { onRefreshFailed?.invoke(error) }
    }

    private fun notifySafely(callback: () -> Unit) {
        try {
            callback()
        } catch (e: Exception) {
            // Application callbacks must not change refresh classification or retry behavior.
            logFailure(e)
        }
    }

    fun destroy() { scope.cancel() }
}

package ai.neccton.lighthouse

enum class Environment(internal val baseUrl: String) {
    PRE_DEV("https://v3.mentor-pre-dev.neccton.ai/pic"),
    DEV    ("https://v3.mentor-dev.neccton.ai/pic"),
    STAGE  ("https://v3.mentor-stage.neccton.ai/pic"),
    PROD   ("https://v3.mentor.neccton.ai/pic"),
}

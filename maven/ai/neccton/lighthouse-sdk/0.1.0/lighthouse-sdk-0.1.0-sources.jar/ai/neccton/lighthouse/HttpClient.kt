package ai.neccton.lighthouse

import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.okhttp.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.json.Json

private const val SDK_VERSION = "0.1.0"

internal val httpClient = HttpClient(OkHttp) {
    install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
}

internal suspend inline fun <reified T> authenticatedRequest(
    baseUrl: String, path: String, method: HttpMethod = HttpMethod.Get,
    accessToken: String, body: Any? = null, params: Map<String, String> = emptyMap(),
): T {
    val response = httpClient.request("$baseUrl$path") {
        this.method = method
        header("Authorization", "Bearer $accessToken")
        header("X-SDK-Type", "lighthouse-android")
        header("X-SDK-Version", SDK_VERSION)
        contentType(ContentType.Application.Json)
        params.forEach { (k, v) -> parameter(k, v) }
        if (body != null) setBody(body)
    }
    if (!response.status.isSuccess()) throw ApiError(response.status.value, response.body<String>())
    return response.body()
}

internal suspend inline fun <reified T> unauthenticatedRequest(
    baseUrl: String, path: String, method: HttpMethod = HttpMethod.Post, body: Any? = null,
): T {
    val response = httpClient.request("$baseUrl$path") {
        this.method = method
        header("X-SDK-Type", "lighthouse-android")
        header("X-SDK-Version", SDK_VERSION)
        contentType(ContentType.Application.Json)
        if (body != null) setBody(body)
    }
    if (!response.status.isSuccess()) throw ApiError(response.status.value, response.body<String>())
    return response.body()
}

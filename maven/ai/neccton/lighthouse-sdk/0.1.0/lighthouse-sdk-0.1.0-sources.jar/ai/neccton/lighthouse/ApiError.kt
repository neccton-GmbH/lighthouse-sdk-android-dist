package ai.neccton.lighthouse

class ApiError(val status: Int, message: String) : Exception("HTTP $status: $message")

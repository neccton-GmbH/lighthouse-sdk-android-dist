package ai.neccton.lighthouse

import kotlinx.serialization.Serializable

@Serializable data class CallToAction(val identifier: String, val translation: String)
@Serializable data class MessageContent(val identifier: String, val category: String, val language: String, val country: String, val title: String, val body: String)
@Serializable data class CustomerMessage(val customerMessageId: String, val message: MessageContent, val callToActions: List<CallToAction>, val readDate: String?, val archivedDate: String?, val createDate: String)
@Serializable data class PageResponse<T>(val data: List<T>, val currentPage: Int, val totalPages: Int, val totalItems: Int, val pageSize: Int, val hasNext: Boolean, val hasPrevious: Boolean)
@Serializable data class MessageReadAllResponse(val updatedMessages: Int)

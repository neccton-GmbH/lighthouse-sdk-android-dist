package ai.neccton.lighthouse

object SDKVersion {
    const val current: String = BuildConfig.LIGHTHOUSE_SDK_VERSION
}

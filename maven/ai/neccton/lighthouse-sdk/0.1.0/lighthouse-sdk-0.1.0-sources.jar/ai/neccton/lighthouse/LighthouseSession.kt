package ai.neccton.lighthouse

import io.ktor.http.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import java.time.Instant
import java.util.Base64
import org.json.JSONObject

data class InitializeOptions(
    val env: Environment = Environment.PROD,
    val baseUrl: String? = null,
    val language: String? = null,
    val country: String? = null,
)

data class MessageListOptions(
    val page: Int = 0,
    val limit: Int = 10,
    val language: String? = null,
    val country: String? = null,
)

class LighthouseSession private constructor(
    private val refreshToken: String,
    @Volatile private var accessToken: String,
    private val baseUrl: String,
    private val defaultLanguage: String,
    private val defaultCountry: String,
    private val onRefreshTokenExpired: (() -> Unit)?,
) {
    private val mutex = Mutex()
    private var inflightRefresh: Deferred<Unit>? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    companion object {
        private const val REFRESH_THRESHOLD_MS = 60_000L
        private val EXPIRED_STATUSES = setOf(400, 401, 403)

        suspend fun initialize(
            refreshToken: String,
            options: InitializeOptions = InitializeOptions(),
            onRefreshTokenExpired: (() -> Unit)? = null,
        ): LighthouseSession {
            val url  = options.baseUrl ?: options.env.baseUrl
            val lang = options.language ?: java.util.Locale.getDefault().language.ifBlank { "en" }
            val ctry = options.country  ?: java.util.Locale.getDefault().country.ifBlank { "ZZ" }
            val token = fetchAccessToken(url, refreshToken)
            return LighthouseSession(refreshToken, token, url, lang, ctry, onRefreshTokenExpired)
                .also { it.scheduleRefresh(token) }
        }

        private suspend fun fetchAccessToken(baseUrl: String, refreshToken: String): String {
            @Serializable data class Body(val refreshToken: String)
            @Serializable data class Resp(val accessToken: String)
            return unauthenticatedRequest<Resp>(baseUrl, "/api/v1/authentication/accessToken", body = Body(refreshToken)).accessToken
        }
    }

    private fun scheduleRefresh(token: String) {
        val exp = parseJwtExp(token) ?: return
        val delayMs = exp * 1000L - System.currentTimeMillis() - REFRESH_THRESHOLD_MS
        if (delayMs <= 0) { scope.launch { doRefresh() }; return }
        scope.launch { delay(delayMs); doRefresh() }
    }

    private suspend fun doRefresh() {
        mutex.withLock {
            inflightRefresh?.let { it.await(); return }
            val d = scope.async {
                try {
                    val token = fetchAccessToken(baseUrl, refreshToken)
                    accessToken = token
                    scheduleRefresh(token)
                } catch (e: ApiError) {
                    if (e.status in EXPIRED_STATUSES) onRefreshTokenExpired?.invoke()
                    throw e
                }
            }
            inflightRefresh = d
            try { d.await() } finally { inflightRefresh = null }
        }
    }

    private suspend inline fun <reified T> req(
        path: String, method: HttpMethod = HttpMethod.Get, body: Any? = null, params: Map<String, String> = emptyMap(),
    ): T = try {
        authenticatedRequest(baseUrl, path, method, accessToken, body, params)
    } catch (e: ApiError) {
        if (e.status == 401) { doRefresh(); authenticatedRequest(baseUrl, path, method, accessToken, body, params) }
        else throw e
    }

    private fun localeParams(o: MessageListOptions) = mapOf(
        "language" to (o.language ?: defaultLanguage),
        "country"  to (o.country  ?: defaultCountry),
        "page"     to o.page.toString(),
        "limit"    to o.limit.toString(),
    )

    suspend fun messages(options: MessageListOptions = MessageListOptions())         = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages", params = localeParams(options))
    suspend fun unreadMessages(options: MessageListOptions = MessageListOptions())   = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages/unread", params = localeParams(options))
    suspend fun activeMessages(options: MessageListOptions = MessageListOptions())   = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages/active", params = localeParams(options))
    suspend fun archivedMessages(options: MessageListOptions = MessageListOptions()) = req<PageResponse<CustomerMessage>>("/api/v1/customer/messages/archived", params = localeParams(options))
    suspend fun message(messageId: String, options: MessageListOptions = MessageListOptions()) =
        req<CustomerMessage>("/api/v1/customer/messages/$messageId", params = mapOf("language" to (options.language ?: defaultLanguage), "country" to (options.country ?: defaultCountry)))
    suspend fun markMessageRead(messageId: String): Unit      = req("/api/v1/customer/messages/$messageId/read", method = HttpMethod.Patch)
    suspend fun markAllMessagesRead(): MessageReadAllResponse = req("/api/v1/customer/messages/read-all", method = HttpMethod.Patch)
    suspend fun archiveMessage(messageId: String): Unit       = req("/api/v1/customer/messages/$messageId/archive", method = HttpMethod.Patch)
    suspend fun restoreMessage(messageId: String): Unit      = req("/api/v1/customer/messages/$messageId/restore", method = HttpMethod.Patch)

    suspend fun engageCallToAction(messageId: String, callToActionIdentifier: String): Unit {
        @Serializable data class Body(val engagementTimestamp: String)
        req<Unit>("/api/v1/customer/messages/$messageId/callToActions/$callToActionIdentifier/engagements",
            method = HttpMethod.Post, body = Body(Instant.now().toString()))
    }

    fun destroy() { scope.cancel() }
}

private fun parseJwtExp(token: String): Long? = runCatching {
    val payload = token.split(".").getOrNull(1) ?: return@runCatching null
    val padded = payload + "=".repeat((4 - payload.length % 4) % 4)
    JSONObject(String(Base64.getUrlDecoder().decode(padded))).getLong("exp")
}.getOrNull()
